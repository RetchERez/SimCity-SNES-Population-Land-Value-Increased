Population & Land Value Increased v1.0
SimCity SNES (USA) 
By: Retch

WHAT THIS DOES
This patch makes the 500,000 population milestone much more achievable across several maps; all while keeping the original feel.

- Population multiplier: about +30% toward milestone counters
- Land value constant: slightly wider, more forgiving land value footprint
- Allows the player to win on most maps without terraforming

- Goal: reduce "map lottery" frustration while keeping the core game intact

FILES
- SimCity-MostMaps-v10.ips

REQUIREMENTS
- A clean, headerless "SimCity (USA).sfc" ROM (512 KB)

KNOWN-GOOD BASE ROM CHECKSUMS (SimCity (USA).sfc)
- Size: 524,288 bytes
- CRC32: 8AEDD3A1
- MD5: 23715fc7ef700b3999384d5be20f4db5
- SHA1: 9140ae08d62a562ccb98576ba89f381f9f4f1439

PATCHED ROM CHECKSUMS (for verification after patching)
- CRC32: 1CF83316
- MD5: 595fc2a27e13f13ece90763323bb03c4
- SHA1: 0aa3d5e7c811f5722910ccceb5d7fd6822e8935f

HOW TO APPLY (Floating IPS / Flips recommended)
1) Open Floating IPS (Flips)
2) Click "Apply Patch"
3) Select SimCity-MostMaps-v10.ips
4) Select your clean SimCity (USA).sfc ROM
5) Save the output ROM (example name: SimCity-MostMaps-v10.sfc)
